import java.util.ArrayList;

public class Student
{
    static int lastIDUsed;
    private int numID, averageGrade;
    private double average;
    private String firstName = "", lastName = "";
    private ArrayList<Integer> studentGrades;

    public Student()
    {
        numID = lastIDUsed++;
        lastIDUsed = numID;
        studentGrades = new ArrayList<Integer>();
    }

    public Student(String firstName, String lastName, int ID)
    {
        numID = ID;
        lastIDUsed = numID;
        this.firstName = firstName;
        this.lastName = lastName;
        studentGrades = new ArrayList<Integer>();
    }

    public void setIDNumber(int ID)
    {
        numID = ID;
        lastIDUsed = numID;
    }

    public int getIDNumber()
    {
        return numID;
    }

    public void addGrade(int grade)
    {
        studentGrades.add(grade);
    }

    public double getAverage()
    {
        int count = 0;
        for(double grade : studentGrades)
        {
            average += grade;
            count++;
        }
        average = average / count;
        return average;
    }

    public String toString()
    {
        return studentGrades.toString();
    }

}
