import java.util.ArrayList;

public class CS3B
{
    static int lastSectionNum;
    private String instructorName = "";
    private int sectionNumber;
    private ArrayList<Student> studentList;

    public CS3B()
    {
        instructorName = "Unknown";
        sectionNumber = lastSectionNum++;
        lastSectionNum = sectionNumber;
        studentList = new ArrayList<Student>();
    }

    public CS3B(String name, int sectionNum)
    {
        instructorName = name;
        sectionNumber = sectionNum;
        lastSectionNum = sectionNumber;
        studentList = new ArrayList<Student>();
    }

    public void addStudent(String firstName, String lastName, int IDNum)
    {
        Student s = new Student(firstName, lastName, IDNum);
    }

    public String toString()
    {
        return studentList.toString();
    }
}
