import java.util.Objects;
import java.util.Scanner;

public class tester
{
    public static void main(String[] args)
    {
        String firstName = "", lastName = "";
        int ID = 0;
        Scanner in = new Scanner(System.in);

        CS3B class1 = new CS3B();

        //Add student to list in CS3B object
        class1.addStudent(firstName, lastName, ID);

//        System.out.println("Hello world!");
    }
}