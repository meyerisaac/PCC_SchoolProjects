//File Name: FinalProjectCS002.cpp
//Author: Isaac Meyer
//Email: imeyer@go.pasadena.edu
//Assignment: CS002 Semester Final Project - Hangman
//Description: This program will run a game of hangman that the user chooses to play and keep a record of the scores of all the players as they play
//in an external file
//Last Date Changed: 12/06/2022

#include <iostream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <string>
#include <cstring>
using namespace std;

//Declare constant integers
const int CANVAS_WIDTH = 24, CANVAS_HEIGHT = 12, HANGER_HEIGHT = 6, HANGER_WIDTH = 10, MENU_SIZE = 5, CATEGORY_SIZE = 9, NUM_LETTERS = 26, DELAY = 100;

void getUserName(string& name);
//Gets the user's name
//I: Takes in a call by reference string
//O: No Outputs, will store the inputted name into the call by reference string variable

int Menu(string list[], int size);
//Prompts user to choose a category
//I: Takes in an array of the categories and an int or the size of the array
//O: Returns the integer value of the option selected

void showStatus(int score[], string name);
//Show the current user's score and the current top 3 users as well
//I: Takes in the array for the user's current score and the user's name
//O: No Outputs, will display to the user the current standings and their win rates

void pushBackMax(string top[], string sec[], string third[], string temp[]);
//Given a string temp[] array, sort it into the 3 other inputted arrays
//I: Takes in 4 string arrays
//O: No Outputs, will sort the array with the lowest scores out

int stringToInt(string word);
//Converts a string to an integer
//I: Takes in a string
//O: Returns an integer

string buildFileName(int num);
//Gets the filename from the integer the user inputted
//I: Takes in an integer
//O: Returns a file name

void openFile(ifstream& fin, string name);
//Open the file input stream with the built file name
//I: Takes in an input stream and a file name
//O: No Outputs, returns the opened stream

void readFile(ifstream& fin, vector<string>& words);
//Reads the words from build file onto vector
//I: Takes in the stream and the vector
//O: No Outputs, reads the file onto the vector

void addScore(int score[], string name);
//Update the scores.txt file with the new wins and losses
//I: Takes in an array with the user's win rate and their name
//O: No Outputs, will update the scores.txt file accordingly

int findDifficulty(int choice);
//Find the given difficulty selected by the user
//I: Takes in the category that the user has selected
//O: No Outputs, returns the integer value of the selected difficulty

void divideCategories(vector<string>& words, int difficulty);
//Divides the vector into the 3 difficulty vectors and using the difficulty, selects the correct vector
//I: Takes in the vector of words and the difficulty integer
//O: No Outputs, returns the vector with the selected difficulty

string selectWord(vector<string>& words);
//Select a random word from the vector
//I: Takes in a vector
//O: Outputs a random word from the vector

void sortList(vector<char>& list);
//Precondition: Takes in a vector of characters
//Post-condition: Sorts them into alphabetical order

bool isWordDone(string word, vector<char>& lettersGuessed, vector<char> correctLetters, int state, int repeats);
//Checks if the word has been completed yet or if the user has lost
//I: Takes in the guessed letters, correctly guessed letters, the word, the number of repeating letters, and the state of the hangman
//O: Returns true or false depending on if the user can continue inputting letters or not

void getLetter(string word, vector<char>& lettersGuessed, vector<char>& correctLetters, int& state, int& repeats);
//Get another letter from the user
//I: Takes in the guessed letters, correctly guessed letters, the word, the number of repeating letters, and the state of the hangman
//O: No Outputs, will get a new letter from the user and update the number of repeats accordingly as well

void displayWord(string word, vector<char>& lettersGuessed, vector<char> correctLetters);
//Displays the word and guessed letters in alphabetical order
//I: Takes in the list of letters, correct letters, and the correct word itself
//O: No Outputs, will show the correctly guessed letters as well as all the guessed letters

bool winOrLose(string word, vector<char> correctLetters);
//Checks if the user has won or lost
//I: Takes in the correct word and the vector of correctly guessed letters
//O: Returns true for a win and a false for a loss

void drawHangman(char arr[][CANVAS_WIDTH], int canvasHeight);
//Draws the entire hanger and hangman immediately
//I:Takes in the array and the array height
//O:No Outputs, will leave the array with the hangman drawn

void drawHangman(char arr[][CANVAS_WIDTH], int canvasHeight, int& state, int num);
//Draws the entire hanger and draws the part specified by the state and given integer
//I:Takes in the array and the array height
//O:No Outputs, will leave the array with the hangman drawn

void drawHanger(char arr[][CANVAS_WIDTH], int canvasHeight);
//Initializes the array
//I:Takes in the array, and it's size
//O:No Outputs, initializes the array

void displayHangman(char array[][CANVAS_WIDTH]);
//Show the current state of hangman
//I: Takes in array containing the hangman
//O: No Outputs, just displays the entire 2D array

void delay(int num);
//Causes a short delay in the program
//I: Takes in an integer for the length of time delayed
//O: No Outputs, just causes a momentary stop in the program

int main()
{
    //Declare repeat program character
    char repeatMain = 'y';
    int score[3] = {};
    ifstream fin;
    string menu[MENU_SIZE] = {"Animals", "Apparel", "Nature", "TV Shows", "Random"};
    string name;

    //Get the user's name and store it in all lowercase
    getUserName(name);

    //Repeat program until user wants to stop
    while(tolower(repeatMain) == 'y')
        {
        char array[CANVAS_HEIGHT][CANVAS_WIDTH];
        int state = 0, repeats = 0;
        vector<string> words;

        //From Here

        //Input
        showStatus(score, name);
        int menuOption = Menu(menu, MENU_SIZE);

        //Save file name onto string variable
        string fileName = buildFileName(menuOption);

        //Opens the file we want
        openFile(fin, fileName);
        readFile(fin, words);

        //Processing Functions To Select A Word From File
        divideCategories(words, findDifficulty(menuOption));
        string word = selectWord(words);

        //To Here Is Section 2

        //From Here

        //Array To Hold All Selected Letters
        vector<char> lettersGuessed;
        vector<char> correctLetters;
        correctLetters.resize(word.length());
        int wrong = 0;

        //Loop until user guesses the entire word or loses
        do
        {
            delay(DELAY);
            drawHangman(array, CANVAS_HEIGHT, state, wrong);
            displayHangman(array);
            displayWord(word, lettersGuessed, correctLetters);
            getLetter(word, lettersGuessed, correctLetters, wrong, repeats);
        }while(!isWordDone(word, lettersGuessed, correctLetters, wrong, repeats));

        //Outputs and end of program
        displayHangman(array);
        displayWord(word, lettersGuessed, correctLetters);

        if(winOrLose(word, correctLetters))
        {
            //If win, tell the user and update the win counter
            cout << "You Win!\n";
            score[0]++;
        }
        else
        {
            //If loss, tell the user and update the loss counter
            cout << "You Lose!\n";
            score[1]++;
        }

        //Show the current win rates of the user
        cout << "# of wins:" << score[0] << endl << "# of losses:" << score[1] << endl;
        score[2] = (100 * score[0]) / (score[0] + score[1]);

        //Prompt user to play again
        cout << "Do you want to play again? Y for yes / N for now:\n";
        cin >> repeatMain;
        }

    //Let the user know their win rate before exiting the program
    cout << "You have " << score[0] << " wins, " << score[1] << " losses, and a " << score[2] << "% win percentage.\n";
    addScore(score, name);

    //To Here Is Section 3

    return 0;
}

void getUserName(string& name)
{
    //Ask user for their name
    cout << "What's your name?\n";
    cin >> name;

    //Lowercase the entire name to store into the save file
    for(int i = 0; i < name.length(); i++)
    {
        name[i] = tolower(name[i]);
    }
}

int Menu(string list [], int size)
{
    //Declare temporary variables
    int temp;

    do
    {
        //Prompt user for the category
        cout << "Choose the category desired:\n";
        for(int i = 0; i < size; i++)
        {
            cout << i + 1 << " - " << list[i] << endl;
        }
        cin >> temp;
    }while(temp < 1 || temp > size);

    //Return the selected category
    return temp;
}

void showStatus(int score[], string name)
{
    //Open streams
    ifstream fin;
    openFile(fin, "scores.txt");

    //Creat arrays for the top 3 users and other variables
    string top[2] = {}, second[2] = {},  third[2] = {}, temp[2] = {};
    char eol;
    string next;

    while(!fin.eof())
    {
        while(fin >> eol && eol != '\n')
        {
            fin.putback(eol);

            fin >> next;
            if(!isdigit(next[0]))
            {
                if(next == name)
                {
                    //If found user in file, use the user's win rates and sort it
                    fin >> score[0] >> score[1] >> score[2];
                    temp[0] = next;
                    temp[1] = to_string(score[2]);
                    pushBackMax(top, second, third, temp);
                }
                else
                {
                    //Read current name and use the current name's scores as the win rate and sort it
                    temp[0] = next;
                    fin >> next >> next >> temp[1];
                    pushBackMax(top, second, third, temp);
                }

            }
        }
    }

    delay(DELAY);

    //Output the current win rates and standings
    cout << "Your current score is: " << score[0] << " wins, " << score[1] << " losses, and a " << score[2] << "% win rate.\n";
    cout << "Current Standings:\n"
         << "First - " << top[0] << " - " << top[1] << "% win rate\n"
         << "Second - " << second[0] << " - " << second[1] << "% win rate\n"
         << "Third - " << third[0] << " - " << third[1] << "% win rate\n\n";

    delay(DELAY);

    //Close streams
    fin.close();
}

void pushBackMax(string top[], string sec[], string third[], string temp[])
{
    //Sort the string temp[] into it's appropriate array
    if((stringToInt(temp[1]) >= stringToInt(top[1])) && (stringToInt(temp[1]) >= stringToInt(sec[1])) && (stringToInt(temp[1]) >=
            stringToInt(third[1])))
    {
        third[0] = sec[0];
        third[1] = sec[1];
        sec[0] = top[0];
        sec[1] = top[1];
        top[0] = temp[0];
        top[1] = temp[1];
    }
    else if((stringToInt(temp[1]) >= stringToInt(sec[1])) && (stringToInt(temp[1]) >= stringToInt(third[1])))
    {
        third[0] = sec[0];
        third[1] = sec[1];
        sec[0] = temp[0];
        sec[1] = temp[1];
    }
    else if(stringToInt(temp[1]) >= stringToInt(third[1]))
    {
        third[0] = temp[0];
        third[1] = temp[1];
    }
}

int stringToInt(string word)
{
    int size = word.length() - 1;
    int place = 1;
    int num = 0;

    for(int i = size; i >= 0; i--)
    {
        //Returns the integer equivalent of the current number and add it onto the output num
        switch(word[i])
        {
            case '0':
                num += place * 0;
                break;
            case '1':
                num += place * 1;
                break;
            case '2':
                num += place * 2;
                break;
            case '3':
                num += place * 3;
                break;
            case '4':
                num += place * 4;
                break;
            case '5':
                num += place * 5;
                break;
            case '6':
                num += place * 6;
                break;
            case '7':
                num += place * 7;
                break;
            case '8':
                num += place * 8;
                break;
            case '9':
                num += place * 9;
                break;
            default:
                return 0;
        }
        //Update the current tens place
        place *= 10;
    }

    //Return the converted number
    return num;
}

string buildFileName(int num)
{
    //Given the input integer, return the file name selected
    if(num < 1 || num > MENU_SIZE)
    {
        cout << "Error With buildFileName()\n";
        exit(1);
    }
    else if(num <= 1)
    {
        return "Animal.txt";
    }
    else if(num <= 2)
    {
        return "Apparel.txt";
    }
    else if(num <= 3)
    {
        return "Nature.txt";
    }
    else if(num <= 4)
    {
        return "TV_Shows.txt";
    }
    else
    {
        return "Random.txt";
    }
}

void openFile(ifstream& fin, string name)
{
    //Open File
    fin.open(name);
    //Exit if the file opening fails
    if(fin.fail())
    {
        cout << "File Input Stream Failed To Open\n";
        exit(1);
    }
}

void readFile(ifstream& fin, vector<string>& words)
{
    //Declare temp string
    string temp;

    //Read the category into the vector
    for(int i = 0; i < CATEGORY_SIZE; i++)
    {
        fin >> temp;
        words.push_back(temp);
    }

    //Close file after we're done with it at end of program
    fin.close();
}

void addScore(int score[], string name)
{
    //Open streams
    ifstream fin;
    openFile(fin, "scores.txt");

    ofstream fout;
    fout.open("temp.txt");
    if(fout.fail())
    {
        cout << "addScore() output stream opening failed\n";
        exit(1);
    }

    string next;
    int temp;
    char eol, space = ' ';
    bool foundName = false;

    //Update the user's win rates or add the user's win rate if user name not found
    while(!fin.eof())
    {
        while(fin >> eol && eol != '\n')
        {
            fin.putback(eol);

            fin >> next;

            if(next == name)
            {
                fout << next << space;
                fin >> temp;
                fout << score[0] << space;
                fin >> temp;
                fout << score[1] << space;
                fin >> temp;
                fout << (100 * score[0]) / (score[0] + score[1]) << endl;
                foundName = true;
            }
            else if(!isdigit(next[0]))
            {
                fout << next << space;
                fin >> temp;
                fout << temp << space;
                fin >> temp;
                fout << temp << space;
                fin >> temp;
                fout << temp << endl;
            }
        }
    }

    if(!foundName)
    {
        fout << name << space << score[0] << space << score[1] << space << (100 * score[0]) / (score[0] + score[1]) << endl;
    }

    //Close streams
    fin.close();
    fout.close();

    //Open new streams
    openFile(fin, "temp.txt");
    fout.open("scores.txt");
    if(fout.fail())
    {
        cout << "Output Stream Opening In addScore() Failed\n";
        exit(1);
    }

    //Transcribe everything from the temp file onto the scores.txt file
    while(!fin.eof())
    {
        while(fin >> eol && eol != '\n')
        {
            fin.putback(eol);

            fin >> next;
            fout << next << space;
            fin >> next;
            fout << next << space;
            fin >> next;
            fout << next << space;
            fin >> next;
            fout << next << endl;
        }
    }

    //Close streams
    fin.close();
    fout.close();
}

int findDifficulty(int choice)
{
    //Declare variable
    int num;

    //Prompt user for a difficulty
    do
    {
        cout << "Select a difficulty:\n"
             << "1 - Easy\n"
             << "2 - Medium\n"
             << "3 - Hard\n";
        cin >> num;
    }while(num < 1 || num > 3);

    //Return the user selection
    return ((choice - 1) * 3) + num;
}

void divideCategories(vector<string>& words, int difficulty)
{
    //Declare 3 different vectors
    vector<string> diff1;
    vector<string> diff2;
    vector<string> diff3;
    int counter = 0;

    //Split the main vector into 3
    for(int i = 0; i < CATEGORY_SIZE; i++)
    {
        if(i < 3)
        {
            diff1.push_back(words[i]);
        }
        else if(i < 6)
        {
            diff2.push_back(words[i]);
        }
        else
        {
            diff3.push_back(words[i]);
        }
    }

    //Resize the vector so to hold the difficulty
    words.resize(3);

    //Assign the appropriate difficulty to the words vector
    switch(difficulty % 3)
    {
        case 0:
            for(int i = 0; i < 3; i++)
            {
                words[i] = diff3[i];
            }
            break;
        case 1:
            for(int i = 0; i < 3; i++)
            {
                words[i] = diff1[i];
            }
            break;
        case 2:
            for(int i = 0; i < 3; i++)
            {
                words[i] = diff2[i];
            }
            break;

        default:
            cout << "Error With divideCategories() switch case\n";
            break;
    }
}

string selectWord(vector<string>& words)
{
    //Randomly select a word from the given vector
    int temp;
    srand(time(0));
    temp = (rand() % 3);
    return words[temp];
}

void sortList(vector<char>& list)
{
    //Find the lowest value(earlier alphabet letters) and store it in a temp variable to move it up to the front
    for(int i = 0; i < list.size(); i++)
    {
        char lowest, temp;
        lowest = list[i];
        for(int c = i + 1; c < list.size(); c++)
        {
            if(list[c] < list[i])
            {
                temp = lowest;
                lowest = list[c];
                list[c] = temp;
            }
        }
        list[i] = lowest;
    }
}

bool isWordDone(string word, vector<char>& lettersGuessed, vector<char> correctLetters, int state, int repeats)
{
    //Calculate the number of correctly guessed letters
    int correct = lettersGuessed.size() - state + repeats;

    //If at least 6 wrong letters have been chosen, return true to end loop
    if(state >= 6)
    {
        return true;
    }
    else if(correct > word.length())
    {
        //If the number of correctly chosen letters is more than the number of letters in the word, something is wrong
        cout << "Error in adding logic in isWordDone()\n";
        exit(1);
    }
    else if(correct == word.length())
    {
        //If the number of correctly chosen letters is equal to the number of letters in the world, return true to end the loop
        return true;
    }
    else
    {
        //For all other cases not described above, we are returning false to run the loop again
        return false;
    }
}

void getLetter(string word, vector<char>& lettersGuessed, vector<char>& correctLetters, int& state, int& repeats)
{
    char temp;
    int test = 0;

    //Repeat until program gets a new letter input
    do
    {
        test = 0;

        //Prompt user for a letter
        cout << "Next Letter:\n";
        cin >> temp;

        //Add the selected letter to the list of guessed letters
        for(int i = 0; i < lettersGuessed.size(); i++)
        {
            //Set int test to 1 if the letter has already been chosen
            if(tolower(temp) == lettersGuessed[i])
            {
                test = 1;
            }
        }
        if(test == 1)
        {
            //Tell the user the letter has been chose
            cout << "Letter Already Chosen\n";
        }
    }while(test == 1);

    //Push the new letter into the list of guessed letters
    lettersGuessed.push_back(temp);

    //Set boolean to false
    bool foundLetter = false;

    //Fills in the correct letters list with the guessed letters to reveal the word
    for(int i = 0; i < word.length(); i++)
    {
            if(temp == word[i])
            {
                correctLetters[i] = word[i];
                repeats++;

                //Checks for and updates the counter keeping track or repeating letters
                if(!foundLetter)
                {
                    repeats--;
                }

                //If valid letter was found set boolean to true
                foundLetter = true;
            }
    }

    //If not valid letter was found update states counter(Telling program how many hangman parts to add)
    if(!foundLetter)
    {
        state++;
    }
}

void displayWord(string word, vector<char>& lettersGuessed, vector<char> correctLetters)
{
    //Sort the guessed letters list
    sortList(lettersGuessed);

    //Show all the correctly guessed letters and replace the blanks with an underscore
    for(int i = 0; i < correctLetters.size(); i++)
    {
        if(isalpha(correctLetters[i]))
        {
            cout << correctLetters[i] << ' ';
        }
        else
        {
            cout << "_ ";
        }
    }

    //Shows the user all the guessed letters in alphabetical order
    cout << "     Letters Guessed: ";
    for(int i = 0; i < lettersGuessed.size(); i++)
    {
        cout << lettersGuessed[i] << ' ';
    }
    cout << endl;
}

bool winOrLose(string word, vector<char> correctLetters)
{
    //Check if the current number of correct letters is equal to the length of the word or not
    for(int i = 0; i < word.length(); i++)
    {
        if(word[i] != correctLetters[i])
        {
            return false;
        }
    }
    return true;
}

void drawHangman(char arr[][CANVAS_WIDTH], int canvasHeight)
{
    drawHanger(arr, canvasHeight);

    //Head
    arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 2][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3))] = 'o';

    //Body
    arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 3][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3))] = '|';

    //Left Arm
    arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 3][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3) - 1)] = '/';

    //Right Arm
    arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 3][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3) + 1)] = '\\';

    //Left Leg
    arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 4][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3) - 1)] = '/';

    //Right Leg
    arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 4][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3) + 1)] = '\\';
}

void drawHangman(char arr[][CANVAS_WIDTH], int canvasHeight, int& state, int num)
{
    //If first time running this function, fill out the default array and update state counter
    if(state == 0)
    {
        drawHanger(arr, canvasHeight);
        state = 1;
    }

    switch(num)
    {
        case 0:
            break;
        case 1:
            //Head
            arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 2][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3))] = 'o';
            break;
        case 2:
            //Body
            arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 3][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3))] = '|';
            break;
        case 3:
            //Left Arm
            arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 3][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3) - 1)] = '/';
            break;
        case 4:
            //Right Arm
            arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 3][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3) + 1)] = '\\';
            break;
        case 5:
            //Left Leg
            arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 4][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3) - 1)] = '/';
            break;
        case 6:
            //Right Leg
            arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 4][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3) + 1)] = '\\';
            break;
        default:
            break;
    }
}

void drawHanger(char arr[][CANVAS_WIDTH], int canvasHeight)
{
    //Filling the entire array with spaces
    for(int l = 0; l < CANVAS_WIDTH; l++)
    {
        for(int h = 0; h < canvasHeight; h++)
        {
            arr[h][l] = ' ';
        }
    }

    //Setting the base
    for(int i = (CANVAS_WIDTH / 2) - (HANGER_WIDTH / 2); i < (CANVAS_WIDTH / 2) + (HANGER_WIDTH / 2); i++)
    {
        arr[(canvasHeight / 2) + (HANGER_HEIGHT / 2)][i] = '=';
    }

    //Setting the vertical lines for the hangar
    for(int h = (canvasHeight / 2) - (HANGER_HEIGHT / 2) + 1; h < (canvasHeight / 2) + (HANGER_HEIGHT / 2); h++)
    {
        arr[h][((CANVAS_WIDTH / 2) + (HANGER_WIDTH / 3))] = '|';
    }
    arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2) + 1][((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3))] = '|';

    //Adding the dashed lines and plus signs
    for(int i = ((CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3)) + 1; i < ((CANVAS_WIDTH / 2) + (HANGER_WIDTH / 3)) - 1; i++)
    {
        arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2)][i] = '-';
    }
    arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2)][(CANVAS_WIDTH / 2) - (HANGER_WIDTH / 3)] = '+';
    arr[(canvasHeight / 2) - (HANGER_HEIGHT / 2)][(CANVAS_WIDTH / 2) + (HANGER_WIDTH / 3)] = '+';
}

void displayHangman(char array[][CANVAS_WIDTH])
{
    //Loop through the entire array and output to the screen
    for(int l = 0; l < CANVAS_HEIGHT; l++)
    {
        for(int h = 0; h < CANVAS_WIDTH; h++)
        {
            cout << array[l][h];
        }
        cout << endl;
    }
}

void delay(int num)
{
    int hello = 1;
    for(int i = 0; i < num * 1000000; i++)
    {
        hello++;
        hello--;
    }
}

/*Sample Run:
 *What's your name?
temp
Your current score is: 6 wins, 1 losses, and a 75% win rate.
Current Standings:
First - test - 100% win rate
Second - isaac - 100% win rate
Third - temp - 75% win rate

Choose the category desired:
1 - Animals
2 - Apparel
3 - Nature
4 - TV Shows
5 - Random
2
Select a difficulty:
1 - Easy
2 - Medium
3 - Hard
1



         +---- +
         |     |
               |
               |
               |
               |
       ==========


_ _ _      Letters Guessed:
Next Letter:
a



         +---- +
         |     |
         o     |
               |
               |
               |
       ==========


_ _ _      Letters Guessed: a
Next Letter:
e



         +---- +
         |     |
         o     |
               |
               |
               |
       ==========


_ e e      Letters Guessed: a e
Next Letter:
t



         +---- +
         |     |
         o     |
               |
               |
               |
       ==========


t e e      Letters Guessed: a e t
You Win!
# of wins:7
# of losses:1
Do you want to play again? Y for yes / N for now:
n
You have 7 wins, 1 losses, and a 87% win percentage.

Process finished with exit code 0
 */